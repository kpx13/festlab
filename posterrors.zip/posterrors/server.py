# -*- coding: utf-8 -*-


import os
import tornado.ioloop
import tornado.web
import json
import datetime

class Version(tornado.web.RequestHandler):
    def get(self):
        self.content_type = 'application/json'
	s = json.dumps({"version":"0.1.1"})
        self.write(s)
        
class PostRequest(tornado.web.RequestHandler):
    def post(self):
        s = json.dumps(self.request.arguments)
        filename = str(self.request.remote_ip) + '_' + datetime.datetime.now().strftime('%d.%m.%Y_%H:%M:%S')
        f = open('/'.join([os.path.dirname(os.path.realpath(__file__)), 'posterrors', filename ]), 'w')
        f.write(s)
        f.close()
        self.finish(filename)

application = tornado.web.Application([
    (r'/pinnp/actual(.*)', tornado.web.StaticFileHandler, {'path': os.path.dirname(os.path.realpath(__file__)) + '/pinnp.epf'}),
    (r'/pinnp/version', Version),
    (r'/pinnp/posterrors', PostRequest),
])


def main():
    try:
        application.listen(8384)
        tornado.ioloop.IOLoop.instance().start()
    except KeyboardInterrupt:
        return

if __name__ == '__main__':
    main()
